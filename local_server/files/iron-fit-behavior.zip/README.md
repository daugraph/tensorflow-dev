# iron-fit-behavior

Fits an element in the window, or another element.
