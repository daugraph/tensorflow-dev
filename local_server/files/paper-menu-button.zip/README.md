paper-menu-button
=================

An element that allows composing a trigger and content as a dropdown menu.
