iron-dropdown
=============

An element that implements a simple drop-down menu widget with a trigger and content.
