# iron-checked-element-behavior
Implements an element that has a checked attribute and can be added to a form
