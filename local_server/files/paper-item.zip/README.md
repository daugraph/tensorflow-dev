paper-item
=========

A non-interactive list item.
