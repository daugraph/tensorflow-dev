iron-component-page
===================

Loads Polymer element and behavior documentation using
[Hydrolysis](https://github.com/PolymerLabs/hydrolysis) and renders a complete
documentation page including demos (if available).
