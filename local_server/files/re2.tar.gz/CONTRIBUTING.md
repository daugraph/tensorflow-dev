RE2 uses Gerrit instead of GitHub pull requests.
See the [Contributing](https://github.com/google/re2/wiki/Contribute) wiki page.
