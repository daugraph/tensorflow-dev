# paper-menu

`<paper-menu>` implements an accessible menu control with Material Design styling.
