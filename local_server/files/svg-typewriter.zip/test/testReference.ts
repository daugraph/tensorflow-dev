///<reference path="../typings/chai/chai-assert.d.ts" />
///<reference path="../typings/mocha/mocha.d.ts" />
///<reference path="../typings/d3/d3.d.ts" />
///<reference path="../typings/jquery/jquery.d.ts" />
///<reference path="../typings/jquery.simulate/jquery.simulate.d.ts" />
///<reference path="testUtils.ts" />
///<reference path="../build/svgtypewriter.d.ts" />

///<reference path="globalInitialization.ts" />

///<reference path="testSuite/cacheTestSuite.ts" />
///<reference path="testSuite/domTestSuite.ts" />
///<reference path="testSuite/utilsTestSuite.ts" />
///<reference path="testSuite/tokenizerTestSuite.ts" />
///<reference path="testSuite/wrapperTestSuite.ts" />
///<reference path="testSuite/writerTestSuite.ts" />
///<reference path="testSuite/stringMethodsTestSuite.ts" />
///<reference path="testSuite/measurerTestSuite.ts" />
///<reference path="testSuite/animatorTestSuite.ts" />