/** Feature one is super great! */
Polymer.Base._addFeature({
  num: 123,
  bool: false,
  str: 'ohai',
  array: [1, 2, 3],
  obj: {a: 1, b: 2},
  func: function() {},
});

Polymer.Base._addFeature({
  /** It does things! */
  doesThings: function() {},
});
