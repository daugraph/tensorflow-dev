# Reactive Development

This project makes use of file watching to give you a reactive development
workflow:

1. Start `gulp` (or `gulp watch`).
2. Make changes to code.
3. React to notifications.

Any time you change a file, appropriate tests will be run for that file.

# CLA

Before your patches will be accepted, you'll need to agree to one of the CLAs.See http://polymer.github.io/CONTRIBUTORS.txt.
