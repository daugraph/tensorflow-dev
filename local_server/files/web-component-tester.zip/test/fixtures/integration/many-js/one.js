suite('suite 1', function() {
  test('nested test 1', function() {});
});
test('test 1', function() {});
