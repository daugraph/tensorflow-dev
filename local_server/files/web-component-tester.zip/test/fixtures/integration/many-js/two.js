suite('suite 2', function() {
  test('nested test 2', function() {});
});
test('test 2', function() {});
