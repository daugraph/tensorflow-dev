suite('suite 3', function() {
  test('nested test 3', function() {});
});
test('test 3', function() {});
