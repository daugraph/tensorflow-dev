suite('suite', function() {
  test('nested test', function() {});
});
test('test', function() {});
