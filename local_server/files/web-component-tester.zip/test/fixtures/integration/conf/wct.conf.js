module.exports = {
  plugins: {
    sauce: {
      username: 'abc123',
    },
  },
};
