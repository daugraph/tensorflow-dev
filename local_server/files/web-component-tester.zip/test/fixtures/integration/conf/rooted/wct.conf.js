var path = require('path');

module.exports = {
  root: path.resolve(__dirname, '../../..'),
  suites: ['integration/conf/test'],
};
