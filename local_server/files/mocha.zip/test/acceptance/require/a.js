global.required = (global.required || [])
global.required.push('a.js')
