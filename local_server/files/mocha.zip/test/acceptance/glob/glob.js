describe('globbing test', function(){
  it('should find this test', function(){
    // see glob.sh for details
  })
});
